<li class="uk-active"><a href="#">Active</a></li>
<li><a href="#">Item</a></li>
<li><a href="#">Item</a></li>
<!--<li>-->
<!--    <a href="#">მშობელი</a>-->
<!--    <div class="uk-navbar-dropdown">-->
<!--        <ul class="uk-nav uk-navbar-dropdown-nav">-->
<!--            <li class="uk-active"><a href="#">ერთი</a></li>-->
<!--            <li><a href="#">ორი</a></li>-->
<!--            <li><a href="#">სამი</a></li>-->
<!--        </ul>-->
<!--    </div>-->
<!--</li>-->
<li><a href="#">Item</a></li>
<li><a href="#">Item</a></li>
<li><a href="#">Item</a></li>