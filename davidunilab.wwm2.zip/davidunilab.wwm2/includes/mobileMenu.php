<div id="offcanvas-overlay" uk-offcanvas="overlay: true">
    <div class="uk-offcanvas-bar">

        <button class="uk-offcanvas-close" type="button" uk-close></button>


        <ul>
            <?php include dirname(__DIR__) . '/includes/menuLinks.php'  ?>
        </ul>


    </div>
</div>