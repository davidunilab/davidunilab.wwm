<?php include  __DIR__ . '/includes/head.php' ?>



<div id="profile">

    <section class="uk-section">
        <div class="uk-container">

        </div>
    </section>

    <section class="uk-section">
        <div class="uk-container">

        </div>
    </section>

    <section class="uk-section">
        <div class="uk-container">

        </div>
    </section>




</div>



<?php include  __DIR__ . '/includes/footer.php' ?>
