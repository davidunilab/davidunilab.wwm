<?php include  __DIR__ . '/includes/head.php' ?>



<div id="structure">

    <seciton class="uk-section uk-section-large">
        <div class="uk-container">


            <div uk-grid class="uk-grid-match">
                <div class="uk-width-2-3@l uk-width-2-3@m uk-width-1-1">
                    <div class="glass-effect">
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aperiam cum ex magnam nostrum placeat repudiandae vero. Deleniti dolor dolore id omnis optio possimus quam quod, saepe, sit temporibus tenetur vero!
                    </div>
                </div>

                <div class="uk-width-1-3@l uk-width-1-3@m uk-width-1-1">
                    <div class="page-nav">
                        <ul class="uk-list">
                            <li><a href="#">Combinatorics</a></li>
                            <li><a href="#">Number Theory</a></li>
                            <li><a href="#">Group Theory</a></li>
                            <li><a href="#">Graph Theory</a></li>
                            <li><a href="#">Order Theory</a></li>
                            <li><a href="#">Algebra</a></li>
                        </ul>
                    </div>
                </div>
            </div>



        </div>
    </seciton>

</div>



<?php include  __DIR__ . '/includes/footer.php' ?>
